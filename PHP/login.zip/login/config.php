<?php
    session_start();
    $connect = mysqli_connect("localhost:3306", "root", "", "login");
?>